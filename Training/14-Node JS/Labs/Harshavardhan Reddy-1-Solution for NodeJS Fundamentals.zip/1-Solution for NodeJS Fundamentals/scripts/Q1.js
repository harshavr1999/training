var current = new Date();

const name = "Harsha";
console.log(`Hi ${name}, The current Date and Time is : ${current}`);
