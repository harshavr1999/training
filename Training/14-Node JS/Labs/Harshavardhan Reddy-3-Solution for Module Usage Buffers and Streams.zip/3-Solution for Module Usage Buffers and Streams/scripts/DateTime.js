const  dateAndTime = ()=>{
    return new Date();
}

module.exports = {
    dateAndTime
    };