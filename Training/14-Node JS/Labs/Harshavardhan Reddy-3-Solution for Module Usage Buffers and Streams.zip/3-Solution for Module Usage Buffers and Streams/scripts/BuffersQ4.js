buf = new Buffer(256);

content = buf.write("Node js is simple");
console.log("octets wrote are "+content);