const lion = ()=> {
    return "Roar";
}

module.exports = {
    lion
};