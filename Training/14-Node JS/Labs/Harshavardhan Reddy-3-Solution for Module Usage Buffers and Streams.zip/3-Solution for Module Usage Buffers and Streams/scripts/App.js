var DateTime = require('./DateTime')
var Animal = require('./Animal')
console.log(DateTime.dateAndTime());
console.log(Animal.lion());