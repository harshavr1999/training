package tms.rto.Offence;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface OffenceRepository extends CrudRepository<OffenceEO, Integer> {
	
	@Query("SELECT o FROM OffenceEO o WHERE LOWER(o.offenceType)=LOWER(:givenType)")
	OffenceEO findByOffenceType(@Param("givenType") String gType);
	
	@Query("SELECT o FROM OffenceEO o WHERE o.offenceId=(:givenId)")
	OffenceEO findByOffenceId(@Param("givenId") Integer id);
	
	@Query("SELECT offenceId FROM OffenceEO")
    List<Integer> allOffenceTypeIds();
}
