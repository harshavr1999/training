package tms.rto.Owner;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OwnerServiceImpl implements OwnerService{
	
	@Autowired
	private OwnerRepository ownerRepoRef;
	
	@Override
	public List<OwnerEO> getAllOwners() {
		// TODO Auto-generated method stub
		List<OwnerEO> ownerList = new ArrayList<>();
		ownerRepoRef.findAll().forEach(ownerList::add);
		return ownerList;
	}

	@Override
	public void addOwner(OwnerEO ownerEO) {
		// TODO Auto-generated method stub
		ownerRepoRef.save(ownerEO);
	}
	
	@Override
	public void updateOwner(OwnerEO ownerEO) {
		// TODO Auto-generated method stub
		
		ownerRepoRef.save(ownerEO);
	}

	@Override
	public void deleteOwner(Integer ownerId) {
		// TODO Auto-generated method stub
		ownerRepoRef.deleteById(ownerId);
	}

	@Override
	public OwnerEO getOwnerById(Integer id) {
		// TODO Auto-generated method stub
		OwnerEO ownerEO = ownerRepoRef.findByOwnerId(id);
		return ownerEO;
	}
	
	@Override
    public List<Integer> allOwnerIds() {
        // TODO Auto-generated method stub
        List<Integer> ownerIdList = new ArrayList<Integer>();
        ownerRepoRef.allOwnerIds().forEach(ownerIdList::add);
        return ownerIdList;
    }

}
