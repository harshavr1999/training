package tms.rto.Owner;

import java.util.List;

public interface OwnerService {
	
	public List<OwnerEO> getAllOwners();
	
	public void addOwner(OwnerEO ownerEO);
	
	public void updateOwner(OwnerEO ownerEO);
	
	public void deleteOwner(Integer ownerId);
	
	public OwnerEO getOwnerById(Integer ownerId);
	
	public List<Integer> allOwnerIds();
}
