package tms.rto.Owner;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

public interface OwnerRepository extends CrudRepository<OwnerEO, Integer> {
	
	@Query("SELECT o FROM OwnerEO o WHERE o.ownerId =:givenId")
	OwnerEO findByOwnerId(@Param("givenId") Integer gId);
	
	@Query("SELECT ownerId FROM OwnerEO")
    List<Integer> allOwnerIds();
}
