package tms.rto.Owner;

import java.sql.Date;

import javax.persistence.Column;

import javax.persistence.Entity;

import javax.persistence.Id;

import javax.persistence.Table;

@Entity

@Table(name = "TM_REGDETAILS")

public class RegDetailsEO {

	@Column(name = "APP_NO")

	private Integer appNo;

	@Id

	@Column(name = "VEH_NO")

	private String vehNo;

	@Column(name = "VEH_ID")

	private Integer vehId;

	@Column(name = "OWNER_ID")

	private Integer ownerId;

	@Column(name = "DATE_OF_PURCHASE")

	private Date purchaseDate;

	@Column(name = "DISTRUBUTER_NAME")

	private String Distrubuter;

	public RegDetailsEO() {

		super();

		// TODO Auto-generated constructor stub

	}

	public RegDetailsEO(Integer appNo, String vehNo, Integer vehId, Integer ownerId, Date purchaseDate,

			String distrubuter) {

		super();

		this.appNo = appNo;

		this.vehNo = vehNo;

		this.vehId = vehId;

		this.ownerId = ownerId;

		this.purchaseDate = purchaseDate;

		Distrubuter = distrubuter;

	}

	public Integer getAppNo() {

		return appNo;

	}

	public void setAppNo(Integer appNo) {

		this.appNo = appNo;

	}

	public String getVehNo() {

		return vehNo;

	}

	public void setVehNo(String vehNo) {

		this.vehNo = vehNo;

	}

	public Integer getVehId() {

		return vehId;

	}

	public void setVehId(Integer vehId) {

		this.vehId = vehId;

	}

	public Integer getOwnerId() {

		return ownerId;

	}

	public void setOwnerId(Integer ownerId) {

		this.ownerId = ownerId;

	}

	public Date getPurchaseDate() {

		return purchaseDate;

	}

	public void setPurchaseDate(Date purchaseDate) {

		this.purchaseDate = purchaseDate;

	}

	public String getDistrubuter() {

		return Distrubuter;

	}

	public void setDistrubuter(String distrubuter) {

		Distrubuter = distrubuter;

	}

	@Override

	public String toString() {

		return "RegDetailsEO [appNo=" + appNo + ", vehNo=" + vehNo + ", vehId=" + vehId + ", ownerId=" + ownerId

				+ ", purchaseDate=" + purchaseDate + ", Distrubuter=" + Distrubuter + "]";

	}

}
