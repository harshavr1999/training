package tms.rto.Owner;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
@RequestMapping("/owners")
public class OwnerController {
	
	@Autowired
	private OwnerService ownerServiceRef;
	
	@Autowired
	private RegDeatilsRepository regDetRep;
	
	@RequestMapping("/allOwners")
	public List<OwnerEO> fetchAllOwners() {
		return ownerServiceRef.getAllOwners();
	}
	
//	@RequestMapping(value="/add-owner", method=RequestMethod.POST)
	
	@PostMapping("/addOwner")
	public void addOwner(@RequestBody OwnerEO ownerEO) {
		ownerServiceRef.addOwner(ownerEO);
	}
	
	@PutMapping("/updateOwner")
	public void updateOwner(@RequestBody OwnerEO ownerEO) {
		ownerServiceRef.updateOwner(ownerEO);
	}
	
	@DeleteMapping("/deleteOwner/{ownerId}")
	public void deleteOwner(@PathVariable("ownerId") Integer ownerId){
		ownerServiceRef.deleteOwner(ownerId);
	}
	
	@GetMapping("/showOwner/{ownerId}")
	public OwnerEO showOwner(@PathVariable("ownerId") Integer ownerId){
		return ownerServiceRef.getOwnerById(ownerId);
	}
	
	@GetMapping("/ownerByVehicleNo/{vehNo}")
	public OwnerEO showOwner(@PathVariable("vehNo") String vehNo) {
		Integer ownerId = (regDetRep.getRow(vehNo)).getOwnerId();
		return ownerServiceRef.getOwnerById(ownerId);
	}
	
	@GetMapping("/allOwnerIds")
    public List<Integer> fetchAllOwnerIds(){
        return ownerServiceRef.allOwnerIds();
    }
}
