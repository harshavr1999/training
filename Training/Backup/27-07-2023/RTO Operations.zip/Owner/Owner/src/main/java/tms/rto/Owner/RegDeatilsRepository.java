package tms.rto.Owner;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

public interface RegDeatilsRepository extends CrudRepository<RegDetailsEO, String> {
	
	@Query("SELECT o FROM RegDetailsEO o WHERE UPPER(o.vehNo) = UPPER(:vehNo)")

    public RegDetailsEO getRow(@Param("vehNo")String vehNo);
}
