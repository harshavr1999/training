package training.iqgateway.springboot.SpringBootLombok;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootLombokApplicationTests {

	@Test
	void contextLoads() {
	}

}
