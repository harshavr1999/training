package training.iqgateway.springboot.SpringBootactuator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootActuatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
