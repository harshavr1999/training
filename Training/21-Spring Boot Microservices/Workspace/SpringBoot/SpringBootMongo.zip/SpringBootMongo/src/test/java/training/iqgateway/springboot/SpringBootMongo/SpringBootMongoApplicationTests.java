package training.iqgateway.springboot.SpringBootMongo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootMongoApplicationTests {

	@Test
	void contextLoads() {
	}

}
