package tms.rto.Vehicle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VehicleApplicationTests {

	@Test
	void contextLoads() {
	}

}
