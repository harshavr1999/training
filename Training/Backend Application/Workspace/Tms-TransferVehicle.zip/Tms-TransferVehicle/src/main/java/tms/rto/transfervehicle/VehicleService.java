package tms.rto.transfervehicle;



public interface VehicleService {

	public VehicleEO findByvehicleId(Integer vehId);
	
	
}
