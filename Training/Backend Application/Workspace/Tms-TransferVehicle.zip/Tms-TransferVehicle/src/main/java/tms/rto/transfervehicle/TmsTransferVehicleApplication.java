package tms.rto.transfervehicle;



import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication
public class TmsTransferVehicleApplication {

	
	public static void main(String[] args) {
		SpringApplication.run(TmsTransferVehicleApplication.class, args);
	}


}
