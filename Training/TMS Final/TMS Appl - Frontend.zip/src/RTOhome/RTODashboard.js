// import { Routes, Route } from 'react-router-dom';
// import { BrowserRouter as Router } from 'react-router-dom';
// import AddVehicle from './AddVehicle';
// import ModifyVehicle from './ModifyVehicle';
// import ModifyOwner from './ModifyOwner';
// import Navbar from './Navbar';
// import AddOwner from './AddOwner';
// import VehicleRegistration from './VehicleRegistration';
// import RTOHome from './RTOHome';
// import AddOffenceType from './AddOffenceType';
// import ModifyOffenceType from './ModifyOffenceType';
// import ShowAllOwners from './ShowAllOwners';
// import Report from './Report';



// export default function RTODashboard() {
//     return (
//         <div>
//             <Router>
//                 <Navbar />
//                 <Routes>
//                     <Route path='/rtoHomePage' element={<RTOHome />} />


//                     <Route path='/addvehicle/' element={<AddVehicle />} />
//                     <Route path='/modifyvehicle/' element={<ModifyVehicle />} />
//                     <Route path='/addowner/' element={<AddOwner />} />
//                     <Route path='/modifyowner/' element={<ModifyOwner />} />
//                     <Route path='/showallowners/' element={<ShowAllOwners />} />

//                     <Route path='/vehicleregistration/' element={<VehicleRegistration />} />


//                     <Route path='/addoffencetype/' element={<AddOffenceType />} />
//                     <Route path='/modifyoffencetype/' element={<ModifyOffenceType />} />
//                     <Route path='/reportgeneration/' element={<Report/>} />


//                 </Routes>
//             </Router>
//             {/* <Router>
//                 <Navbar />
//                 <Switch>


//                     <Route exact path='/'><RTOHome /></Route>
//                     <Route path='/addvehicle/'><AddVehicle /></Route>
//                     <Route path='/modifyvehicle/'><ModifyVehicle /></Route>

//                     <Route path='/addowner/'><AddOwner /></Route>
//                     <Route path='/modifyowner/'><ModifyOwner /></Route>
//                     <Route path='/ownerdetail/'><Album /></Route>

//                     <Route path='/vehicleregistration/'><VehicleRegistration /></Route>


//                     <Route path='/addoffencetype/'><AddOffenceType /></Route>
//                     <Route path='/modifyoffencetype/'><ModifyOffenceType /></Route>



//                     <Route path='' element={<AddVehicle />}/>
//                     <Route path='' element={<ModifyVehicle />}/>
//                     <Route path='/oldaddowner/' element={<AddOwner />}/>
//                     <Route path='/modifyowner/' element={<ModifyOwner />}/>
//                     <Route path='' element={<SignUp />}/>
//                     <Route path='' element={<Album />}/> 

//                     <Route path='/' element={<BasicGrid />}/>
//                     <Route path='/' element={<Blog />}/> 


//                 </Switch>
//             </Router> */}
//         </div>
//     )
// }