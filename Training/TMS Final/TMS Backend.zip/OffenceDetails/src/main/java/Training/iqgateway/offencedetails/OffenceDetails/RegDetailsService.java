package Training.iqgateway.offencedetails.OffenceDetails;

public interface RegDetailsService {
	public RegDetailsEO getRow(String vehNo);

}
