package Training.iqgateway.offencedetails.OffenceDetails;


public interface OffenceService {
	
    public String addOffence(OffenceDetailsEO offenceDetailsRef);
}
