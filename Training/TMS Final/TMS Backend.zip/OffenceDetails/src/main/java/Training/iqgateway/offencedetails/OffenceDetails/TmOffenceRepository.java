package Training.iqgateway.offencedetails.OffenceDetails;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface TmOffenceRepository extends CrudRepository<OffenceEO, Integer>{
	
	@Query("SELECT o FROM  OffenceEO o WHERE LOWER(o.offenceType)=LOWER(:offType)")
	public OffenceEO  findOffenceByType(@Param("offType")  String oType);
	
}
