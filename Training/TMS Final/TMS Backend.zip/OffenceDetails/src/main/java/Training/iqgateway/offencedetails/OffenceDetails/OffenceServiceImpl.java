package Training.iqgateway.offencedetails.OffenceDetails;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OffenceServiceImpl implements OffenceService {
	
  @Autowired
  private OffenceRepository offenceRepRef;
     
	@Override
	public String addOffence(OffenceDetailsEO offenceDetailsRef) {
		// TODO Auto-generated method stub
		 offenceRepRef.save(offenceDetailsRef);
		 
		 return "success";
	}
	
	
	

}
