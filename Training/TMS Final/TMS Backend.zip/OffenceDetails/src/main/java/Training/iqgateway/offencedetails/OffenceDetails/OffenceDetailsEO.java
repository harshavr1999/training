package Training.iqgateway.offencedetails.OffenceDetails;

import java.sql.Date;
import java.util.Arrays;

import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="TM_OFFENCE_DETAILS")
public class OffenceDetailsEO {
	
	@Column(name = "VEH_NO")
	private String vehNo;
	
	
	@Lob
	@Column(name = "IMAGE")
	private byte[] image;
	
	@Id
	@Column(name = "OFFENCE_DETAIL_ID")
	@GeneratedValue( strategy =  GenerationType.SEQUENCE, generator="my_seq")
	@SequenceGenerator(name="my_seq" ,sequenceName="TM_OFFENCE_DETAIL_ID_SEQ", allocationSize = 1)
	private Integer offenceDetailId;
	
	@Column(name = "OFFENCE_STATUS")
	private String offenceStatus;
	
	@Column(name = "OFFENCE_ID")
	private Integer offenceId;
	
	@Column(name = "TIME")
	private Date offenceDate;
	
	@Column(name = "PLACE")
	private String place;
	
	@Column(name = "REPORTED_BY")
	private String reportedBy;

	public OffenceDetailsEO() {
		
		// TODO Auto-generated constructor stub
	}

	public OffenceDetailsEO(String vehNo, byte[] image, Integer offenceDetailId, String offenceStatus,
			Integer offenceId, Date offenceDate, String place, String reportedBy) {
		super();
		this.vehNo = vehNo;
		this.image = image;
		this.offenceDetailId = offenceDetailId;
		this.offenceStatus = offenceStatus;
		this.offenceId = offenceId;
		this.offenceDate = offenceDate;
		this.place = place;
		this.reportedBy = reportedBy;
	}

	public String getVehNo() {
		return vehNo;
	}

	public void setVehNo(String vehNo) {
		this.vehNo = vehNo;
	}

	public byte[] getImage() {
		return image;
	}

	public void setImage(byte[] image) {
		this.image = image;
	}

	public Integer getOffenceDetailId() {
		return offenceDetailId;
	}

	public void setOffenceDetailId(Integer offenceDetailId) {
		this.offenceDetailId = offenceDetailId;
	}

	public String getOffenceStatus() {
		return offenceStatus;
	}

	public void setOffenceStatus(String offenceStatus) {
		this.offenceStatus = offenceStatus;
	}

	public Integer getOffenceId() {
		return offenceId;
	}

	public void setOffenceId(Integer offenceId) {
		this.offenceId = offenceId;
	}

	public Date getOffenceDate() {
		return offenceDate;
	}

	public void setOffenceDate(Date offenceDate) {
		this.offenceDate = offenceDate;
	}

	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

	public String getReportedBy() {
		return reportedBy;
	}

	public void setReportedBy(String reportedBy) {
		this.reportedBy = reportedBy;
	}

	@Override
	public String toString() {
		return "OffenceDetailsDTO [vehNo=" + vehNo + ", image=" + Arrays.toString(image) + ", offenceDetailId="
				+ offenceDetailId + ", offenceStatus=" + offenceStatus + ", offenceId=" + offenceId + ", offenceDate="
				+ offenceDate + ", place=" + place + ", reportedBy=" + reportedBy + "]";
	}
	
	

}
