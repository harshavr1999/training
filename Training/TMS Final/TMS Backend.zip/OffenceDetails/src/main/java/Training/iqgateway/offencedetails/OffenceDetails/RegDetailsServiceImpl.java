package Training.iqgateway.offencedetails.OffenceDetails;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RegDetailsServiceImpl implements RegDetailsService {

	@Autowired
	private RegDetailsRepository RegDetailsRepositoryRef;

	@Override
	public RegDetailsEO getRow(String vehNo) {

		return RegDetailsRepositoryRef.getRow(vehNo);

	}

}
