package Training.iqgateway.offencedetails.OffenceDetails;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Entity
@Table(name="TM_OFFENCE")
public class OffenceEO {
    @Id
    @Column(name="OFFENCE_ID")
    private Integer offenceId;

    @Column(name="OFFENCE_TYPE")
    private String offenceType;

    @Column(name="PENALTY")
    private Integer penalty;

    @Column(name="VEH_TYPE")
    private String vehType;

	public OffenceEO() {
		
		// TODO Auto-generated constructor stub
	}

	public Integer getOffecneId() {
		return offenceId;
	}

	public void setOffecneId(Integer offecneId) {
		this.offenceId = offecneId;
	}

	public String getOffenceType() {
		return offenceType;
	}

	public void setOffenceType(String offenceType) {
		this.offenceType = offenceType;
	}

	public Integer getPenalty() {
		return penalty;
	}

	public void setPenalty(Integer penalty) {
		this.penalty = penalty;
	}

	public String getVehType() {
		return vehType;
	}

	public void setVehType(String vehType) {
		this.vehType = vehType;
	}

	public OffenceEO(Integer offenceId, String offenceType, Integer penalty, String vehType) {
		super();
		this.offenceId = offenceId;
		this.offenceType = offenceType;
		this.penalty = penalty;
		this.vehType = vehType;
	}

	@Override
	public String toString() {
		return "OffenceEO [offenceId=" + offenceId + ", offenceType=" + offenceType + ", penalty=" + penalty
				+ ", vehType=" + vehType + "]";
	}
    
    
    
}