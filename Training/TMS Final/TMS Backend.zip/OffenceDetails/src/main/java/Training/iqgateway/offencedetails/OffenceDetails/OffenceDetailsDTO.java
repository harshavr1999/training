package Training.iqgateway.offencedetails.OffenceDetails;

import java.sql.Date;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Arrays;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import org.springframework.web.multipart.MultipartFile;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

public class OffenceDetailsDTO {

	private Integer offenceDetailId;

	//private Integer offencId;

	private String place;

	private Date time;

	private String reportedBy;

	private String offenceStatus;

	private String vehNo;

	private byte[] image;
	
	private String offenceType;
	
	public String getOffenceType() {
		return offenceType;
	}

	public void setOffenceType(String offenceType) {
		this.offenceType = offenceType;
	}

	public Integer getOffenceDetailId() {
		return offenceDetailId;
	}

	public void setOffenceDetailId(Integer offenceDetailId) {
		this.offenceDetailId = offenceDetailId;
	}

//	public Integer getOffencId() {
//		return offencId;
//	}
//
//	public void setOffencId(Integer offencId) {
//		this.offencId = offencId;
//	}

	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

	public Date getTime() {
		return time;
	}

	public void setTime(Date time) {
		this.time = time;
	}

	public String getReportedBy() {
		return reportedBy;
	}

	public void setReportedBy(String reportedBy) {
		this.reportedBy = reportedBy;
	}

	public String getOffenceStatus() {
		return offenceStatus;
	}

	public void setOffenceStatus(String offenceStatus) {
		this.offenceStatus = offenceStatus;
	}

	public String getVehNo() {
		return vehNo;
	}

	public void setVehNo(String vehNo) {
		this.vehNo = vehNo;
	}

	public byte[] getImage() {
		return image;
	}

	public void setImage(byte[] image) {
		this.image = image;
	}

	public OffenceDetailsDTO() {

		// TODO Auto-generated constructor stub
	}

	public OffenceDetailsDTO(Integer offenceDetailId,String place, Date time, String reportedBy,
			String offenceStatus, String vehNo, byte[] image, String offenceType) {
		super();
		this.offenceDetailId = offenceDetailId;
		//this.offencId = offencId;
		this.place = place;
		this.time = time;
		this.reportedBy = reportedBy;
		this.offenceStatus = offenceStatus;
		this.vehNo = vehNo;
		this.image = image;
		this.offenceType = offenceType;
	}

	

}
