package Training.iqgateway.offencedetails.OffenceDetails;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TmOffenceServiceImpl implements TmOffenceService {
	@Autowired
    private TmOffenceRepository tmOffenceRepRef;
	
	@Override
	public OffenceEO getOffenceId(String offenceType) {
		// TODO Auto-generated method stub
		return tmOffenceRepRef.findOffenceByType(offenceType);
	}

	@Override
	public List<OffenceEO> getAllOffences() {
		// TODO Auto-generated method stub
		return (List<OffenceEO>) tmOffenceRepRef.findAll();
	}

}
