package Training.iqgateway.offencedetails.OffenceDetails;

import java.util.List;

public interface TmOffenceService {
	
	 OffenceEO getOffenceId(String offenceType);
     List<OffenceEO> getAllOffences();
     
}
