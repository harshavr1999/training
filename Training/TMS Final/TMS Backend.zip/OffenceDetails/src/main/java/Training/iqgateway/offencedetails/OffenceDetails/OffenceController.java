package Training.iqgateway.offencedetails.OffenceDetails;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
public class OffenceController {

	@Autowired
	private OffenceService offenceSerRef;

	@Autowired
	private TmOffenceService tmOffenceSerRef;

	@Autowired
	private RegDetailsService RegDetailsServiceRef;

	@PostMapping("/addoffence")
	@CrossOrigin
	public ResponseEntity<String> addOffence(@ModelAttribute OffenceDetailsDTO offenceDetails) {

		try {

			System.out.println(offenceDetails.getOffenceType());

			OffenceEO oe = tmOffenceSerRef.getOffenceId(offenceDetails.getOffenceType());
			System.out.println(oe);
			System.out.println("I AM HERE");

			OffenceDetailsEO offDetDTO = new OffenceDetailsEO();
			offDetDTO.setOffenceId(oe.getOffecneId());
			offDetDTO.setVehNo(offenceDetails.getVehNo());
			offDetDTO.setImage(offenceDetails.getImage());
			// offDetDTO.setOffenceDetailId(1);
			if(offenceDetails.getOffenceStatus().equals("1")) {
				offDetDTO.setOffenceStatus("UNPAID");
			}
			else {
				offDetDTO.setOffenceStatus("PAID");
			}
			//offDetDTO.setOffenceStatus(offenceDetails.getOffenceStatus());
			// offDetDTO.setOffenceId(offenceDetails.getOffencId());
			offDetDTO.setOffenceDate(offenceDetails.getTime());
			offDetDTO.setPlace(offenceDetails.getPlace());
			offDetDTO.setReportedBy((offenceDetails.getReportedBy()).toUpperCase());

			offenceSerRef.addOffence(offDetDTO);
			return ResponseEntity.ok("offence added Successfully");

		} catch (Exception e) {
			e.printStackTrace();
			return ResponseEntity.ok("failed");
		}

	}

	@GetMapping("/getalloffences")
	@CrossOrigin
	public List<OffenceEO> getAllOffences() {
		return tmOffenceSerRef.getAllOffences();

	}

	@GetMapping("/{vehNum}")
	@CrossOrigin
	public boolean CheckVehicleNumber(@PathVariable("vehNum") String VehNum) {

		RegDetailsEO obj = RegDetailsServiceRef.getRow(VehNum);

		return (obj != null) ? true : false;

	}
}
