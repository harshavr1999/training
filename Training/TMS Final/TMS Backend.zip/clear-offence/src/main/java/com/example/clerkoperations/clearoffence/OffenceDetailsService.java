package com.example.clerkoperations.clearoffence;

import java.util.List;

public interface OffenceDetailsService {

   public List<OffenceDetailsEO> listAllOffenceByVehicleNumber(String givenVehicleNumber);
   
   public void changeStatusOnId(Integer id);
    
}
