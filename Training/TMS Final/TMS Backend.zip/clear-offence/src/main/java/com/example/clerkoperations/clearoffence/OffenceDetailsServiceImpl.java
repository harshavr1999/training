package com.example.clerkoperations.clearoffence;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

@Service

public class OffenceDetailsServiceImpl implements OffenceDetailsService {

	@Autowired(required=true)
	 private OffenceDetailsRepository offenceDetailsRepositoryRef;
	
	
	@Override
	public List<OffenceDetailsEO> listAllOffenceByVehicleNumber(String givenVehicleNumber) {
		List<OffenceDetailsEO> allOffences= offenceDetailsRepositoryRef.getAllOffencesByVehicleNumber(givenVehicleNumber);
		System.out.println(allOffences.toString());
		return  allOffences;
	}


	@Override
	public void changeStatusOnId(Integer id) {
		offenceDetailsRepositoryRef.changeStatusBasedOnId(id);	
	}

}
