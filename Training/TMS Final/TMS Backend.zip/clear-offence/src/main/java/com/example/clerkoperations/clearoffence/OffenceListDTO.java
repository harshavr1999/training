package com.example.clerkoperations.clearoffence;

import java.sql.Date;


public class OffenceListDTO {

	private Integer Id;
    private Integer offenceTypeId;
    private String location;
    private String reportedBy;
    private Date date;
    private Integer penalty;
    private String Status;
    
	public OffenceListDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OffenceListDTO(Integer id, Integer offenceTypeId, String location, String reportedBy, Date date,
			Integer penalty, String status) {
		super();
		this.Id = id;
		this.offenceTypeId = offenceTypeId;
		this.location = location;
		this.reportedBy = reportedBy;
		this.date = date;
		this.penalty = penalty;
		Status = status;
	}

	public Integer getId() {
		return Id;
	}

	public void setId(Integer id) {
		Id = id;
	}

	public Integer getOffenceTypeId() {
		return offenceTypeId;
	}

	public void setOffenceTypeId(Integer offenceTypeId) {
		this.offenceTypeId = offenceTypeId;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getReportedBy() {
		return reportedBy;
	}

	public void setReportedBy(String reportedBy) {
		this.reportedBy = reportedBy;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public Integer getPenalty() {
		return penalty;
	}

	public void setPenalty(Integer penalty) {
		this.penalty = penalty;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

	@Override
	public String toString() {
		return "OffenceListDTO [Id=" + Id + ", offenceTypeId=" + offenceTypeId + ", location=" + location
				+ ", reportedBy=" + reportedBy + ", date=" + date + ", penalty=" + penalty + ", Status=" + Status + "]";
	}
	
	

}