package com.example.clerkoperations.clearoffence;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "TM_OFFENCE")
public class OffenceEO {

	@Id
	@Column(name="OFFENCE_ID")
	private Integer offenceId;
	
	@Column(name="OFFENCE_TYPE")
	private String offenceType;
	
	@Column(name="PENALTY")
	private Integer penalty;
	
	@Column(name="VEH_TYPE")
	private String vehType;
}
