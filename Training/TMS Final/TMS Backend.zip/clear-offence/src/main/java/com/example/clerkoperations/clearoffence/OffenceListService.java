package com.example.clerkoperations.clearoffence;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OffenceListService {

	@Autowired(required = true)
	private OffenceDetailsService OffenceDetailsServiceRef;

	@Autowired(required = true)
	private OffenceService OffenceServiceRef;

//	@Autowired
//	private List<OffenceListDTO> DTOList;

	public List<OffenceListDTO> listDetailsByVehNo(String givenVehicleNumber) {

		List<OffenceListDTO> DTOList = new ArrayList<>();

		List<OffenceDetailsEO> odList = OffenceDetailsServiceRef.listAllOffenceByVehicleNumber(givenVehicleNumber);

		for (OffenceDetailsEO od : odList) {
			OffenceListDTO offenceListDTO = new OffenceListDTO();
			
			offenceListDTO.setId(od.getOffenceDetailId());
			offenceListDTO.setOffenceTypeId(od.getOffenceId());
			offenceListDTO.setLocation(od.getPlace());
			offenceListDTO.setReportedBy(od.getReportedBy());
			offenceListDTO.setDate(od.getTime());
			offenceListDTO.setPenalty(OffenceServiceRef.getPenaltyById(od.getOffenceId()));
			offenceListDTO.setStatus(od.getOffenceStatus());

			DTOList.add(offenceListDTO);
		}

		return DTOList;
	}

}
