package com.example.clerkoperations.clearoffence;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OffenceServiceImpl implements OffenceService {

	@Autowired
	private OffenceRepository OffenceRepositoryRef; 
	
	@Override
	public Integer getPenaltyById(Integer givenOffenceId) {
		
		return OffenceRepositoryRef.getPenaltyByOffenceId(givenOffenceId);
	}

}
