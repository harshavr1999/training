package com.example.clerkoperations.clearoffence;

import java.util.ArrayList;
import java.util.List;

import org.assertj.core.util.Arrays;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping("/clear-offence")
public class ClearOffenceController {
  
	@Autowired(required=true)
	private OffenceDetailsService OffenceDetailsServiceRef;
	
	@Autowired(required=true)
	private OffenceService OffenceServiceRef;
	
	@Autowired(required=true)
	private OffenceListService OffenceListServiceRef;
	
	@Autowired
	private OffenceDetailsRepository OffenceDetailsRepositoryRef; 
	
	@RequestMapping("/{givenVehicleNumber}")
	@CrossOrigin
	public List<OffenceListDTO> getAllOffence(@PathVariable("givenVehicleNumber") String givenVehicleNumber){
		return OffenceListServiceRef.listDetailsByVehNo(givenVehicleNumber);
	}
	
	
	@PostMapping("/changeStatus")
	@CrossOrigin
	public String changeStatus(@RequestBody List<String> ids){
		for(String id : ids){
			Integer oid =Integer.parseInt(id);
	OffenceDetailsEO row =  OffenceDetailsRepositoryRef.getRowObj(oid);
	row.setOffenceStatus("PAID");
	OffenceDetailsRepositoryRef.save(row);
		}
		return "StatusChanged";
	}
	
	

}
