package com.example.clerkoperations.clearoffence;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;


@Entity
@Table(name="TM_OFFENCE_DETAILS")
public class OffenceDetailsEO {
	
	@Id
	@Column(name="OFFENCE_DETAIL_ID")
	private Integer offenceDetailId;
	
	@Column(name="OFFENCE_ID")
	private Integer offenceId;
	
	@Column(name="PLACE")
	private String place;
	
	@Column(name="TIME")
	private Date time;
	
	@Column(name="REPORTED_BY")
	private String reportedBy;

	@Column(name="OFFENCE_STATUS")
	private String offenceStatus;
	
	@Column(name="VEH_NO")
	private String vehNo;

	public OffenceDetailsEO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OffenceDetailsEO(Integer offenceDetailId, Integer offenceId, String place, Date time, String reportedBy,
			String offenceStatus, String vehNo) {
		super();
		this.offenceDetailId = offenceDetailId;
		this.offenceId = offenceId;
		this.place = place;
		this.time = time;
		this.reportedBy = reportedBy;
		this.offenceStatus = offenceStatus;
		this.vehNo = vehNo;
	}

	public Integer getOffenceDetailId() {
		return offenceDetailId;
	}

	public void setOffenceDetailId(Integer offenceDetailId) {
		this.offenceDetailId = offenceDetailId;
	}

	public Integer getOffenceId() {
		return offenceId;
	}

	public void setOffenceId(Integer offenceId) {
		this.offenceId = offenceId;
	}

	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

	public Date getTime() {
		return time;
	}

	public void setTime(Date time) {
		this.time = time;
	}

	public String getReportedBy() {
		return reportedBy;
	}

	public void setReportedBy(String reportedBy) {
		this.reportedBy = reportedBy;
	}

	public String getOffenceStatus() {
		return offenceStatus;
	}

	public void setOffenceStatus(String offenceStatus) {
		this.offenceStatus = offenceStatus;
	}

	public String getVehNo() {
		return vehNo;
	}

	public void setVehNo(String vehNo) {
		this.vehNo = vehNo;
	}

	@Override
	public String toString() {
		return "OffenceDetailsEO [offenceDetailId=" + offenceDetailId + ", offenceId=" + offenceId + ", place=" + place
				+ ", time=" + time + ", reportedBy=" + reportedBy + ", offenceStatus=" + offenceStatus + ", vehNo="
				+ vehNo + "]";
	}         
	

}
