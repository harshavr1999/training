package com.example.clerkoperations.clearoffence;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface OffenceDetailsRepository extends CrudRepository<OffenceDetailsEO, Integer> {


	@Query("SELECT o FROM OffenceDetailsEO o WHERE UPPER(o.vehNo)=UPPER(:given_veh_no)AND UPPER(o.offenceStatus)='UNPAID'")
	public List<OffenceDetailsEO> getAllOffencesByVehicleNumber(@Param("given_veh_no") String veh_no);

	
	@Query("SELECT o FROM OffenceDetailsEO o WHERE o.offenceDetailId=(:givenId)")
	public OffenceDetailsEO getRowObj(@Param("givenId")Integer givenId);
	
	
	@Query("UPDATE OffenceDetailsEO o SET o.offenceStatus = 'PAID' WHERE o.offenceDetailId = (:given_Id)")
	public void changeStatusBasedOnId(@Param("given_Id")Integer Id );

}
