package com.example.clerkoperations.clearoffence;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface OffenceRepository extends CrudRepository<OffenceEO, Integer> {

	@Query("SELECT o.penalty FROM OffenceEO o WHERE o.offenceId = (:givenOffenceId)")
	public Integer getPenaltyByOffenceId(@Param("givenOffenceId")  Integer givenOffenceId);
}
