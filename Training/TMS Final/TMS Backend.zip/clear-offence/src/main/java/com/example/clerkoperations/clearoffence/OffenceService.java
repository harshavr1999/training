package com.example.clerkoperations.clearoffence;

public interface OffenceService {

	public Integer getPenaltyById(Integer givenOffenceId);
	
}
