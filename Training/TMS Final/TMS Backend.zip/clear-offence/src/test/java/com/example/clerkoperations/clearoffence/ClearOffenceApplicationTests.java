package com.example.clerkoperations.clearoffence;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClearOffenceApplicationTests {

	@Test
	void contextLoads() {
	}

}
