package training.iqgateway.generatereportservice.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import training.iqgateway.generatereportservice.entities.OwnerDetailsEO;

@Repository
public interface OwnerDetailsRepository extends CrudRepository<OwnerDetailsEO, Integer> {

}
