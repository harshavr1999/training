package training.iqgateway.generatereportservice.entities;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name="TM_VEHICLEDETAILS")
//@Getter
//@Setter
//@NoArgsConstructor
//@AllArgsConstructor
//@ToString
public class VehicleDetailsEO {
	
	@Id
	@Column(name="VEH_ID")
	private Integer vehicleId;
	
	@Column(name="VEH_TYPE")
	private String vehicleType;
	
	@Column(name="ENGINE_NO")
	private String engineNo;
	
	@Column(name="MODEL_NO")
	private String modelNo;
	
	@Column(name="VEH_NAME")
	private String vehicleName;
	
	@Column(name="VEH_COLOR")
	private String vehicleColor;
	
	@Column(name="MANUFACTURER_NAME")
	private String manufacturer;
	
	@Column(name="DATE_OF_MANUFACTURE")
	private Date manufactureDate;
	
	@Column(name="NO_OF_CYLINDERS")
	private Integer cylinders;
	
	@Column(name="CUBIC_CAPACITY")
	private Integer cc;
	
	@Column(name="FUEL_USED")
	private String fuelUsed;
	
	public VehicleDetailsEO() {
		// TODO Auto-generated constructor stub
	}

	public VehicleDetailsEO(Integer vehicleId, String vehicleType, String engineNo, String modelNo, String vehicleName,
			String vehicleColor, String manufacturer, Date manufactureDate, Integer cylinders, Integer cc,
			String fuelUsed) {
		super();
		this.vehicleId = vehicleId;
		this.vehicleType = vehicleType;
		this.engineNo = engineNo;
		this.modelNo = modelNo;
		this.vehicleName = vehicleName;
		this.vehicleColor = vehicleColor;
		this.manufacturer = manufacturer;
		this.manufactureDate = manufactureDate;
		this.cylinders = cylinders;
		this.cc = cc;
		this.fuelUsed = fuelUsed;
	}

	public Integer getVehicleId() {
		return vehicleId;
	}

	public void setVehicleId(Integer vehicleId) {
		this.vehicleId = vehicleId;
	}

	public String getVehicleType() {
		return vehicleType;
	}

	public void setVehicleType(String vehicleType) {
		this.vehicleType = vehicleType;
	}

	public String getEngineNo() {
		return engineNo;
	}

	public void setEngineNo(String engineNo) {
		this.engineNo = engineNo;
	}

	public String getModelNo() {
		return modelNo;
	}

	public void setModelNo(String modelNo) {
		this.modelNo = modelNo;
	}

	public String getVehicleName() {
		return vehicleName;
	}

	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}

	public String getVehicleColor() {
		return vehicleColor;
	}

	public void setVehicleColor(String vehicleColor) {
		this.vehicleColor = vehicleColor;
	}

	public String getManufacturer() {
		return manufacturer;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public Date getManufactureDate() {
		return manufactureDate;
	}

	public void setManufactureDate(Date manufactureDate) {
		this.manufactureDate = manufactureDate;
	}

	public Integer getCylinders() {
		return cylinders;
	}

	public void setCylinders(Integer cylinders) {
		this.cylinders = cylinders;
	}

	public Integer getCc() {
		return cc;
	}

	public void setCc(Integer cc) {
		this.cc = cc;
	}

	public String getFuelUsed() {
		return fuelUsed;
	}

	public void setFuelUsed(String fuelUsed) {
		this.fuelUsed = fuelUsed;
	}

	@Override
	public String toString() {
		return "VehicleDetailsEO [vehicleId=" + vehicleId + ", vehicleType=" + vehicleType + ", engineNo=" + engineNo
				+ ", modelNo=" + modelNo + ", vehicleName=" + vehicleName + ", vehicleColor=" + vehicleColor
				+ ", manufacturer=" + manufacturer + ", manufactureDate=" + manufactureDate + ", cylinders=" + cylinders
				+ ", cc=" + cc + ", fuelUsed=" + fuelUsed + "]";
	}
	
}
