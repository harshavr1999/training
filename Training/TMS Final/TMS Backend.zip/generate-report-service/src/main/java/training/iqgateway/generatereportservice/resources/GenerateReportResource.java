package training.iqgateway.generatereportservice.resources;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import training.iqgateway.generatereportservice.dto.Details;
import training.iqgateway.generatereportservice.dto.Offence;
import training.iqgateway.generatereportservice.services.DetailService;
import training.iqgateway.generatereportservice.services.OffenceService;

@RestController
@CrossOrigin
@RequestMapping("/report")
public class GenerateReportResource {
	
	@Autowired
	private DetailService detailServiceRef;
	@Autowired
	private OffenceService offenceServiceRef;
	
	@Autowired
	private RestTemplate restTemplate;
	
	@RequestMapping("/details")
	public List<Details> getDetails() {
		return detailServiceRef.getAllDetails();
	}
	
	@RequestMapping("/offences")
	public List<Offence> getOffences() {
		return offenceServiceRef.getAllOffences();
	}
	
}
