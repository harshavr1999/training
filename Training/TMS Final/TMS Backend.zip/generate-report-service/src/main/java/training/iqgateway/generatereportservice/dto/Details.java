package training.iqgateway.generatereportservice.dto;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;


//@Getter
//@Setter
//@Data
//@NoArgsConstructor
//@AllArgsConstructor
//@ToString
public class Details {
	
	private Integer offenceDetailId;
	private String vehicleNumber;
	private String vehicleType;
	private String offenceType;
	private Date date;
	private String status;
	private String reportedBy;
	private String place;
	
	@Autowired
	private OwnerDetail owner;

	public Details() {
		// TODO Auto-generated constructor stub
	}

	public Details(Integer offenceDetailId, String vehicleNumber, String vehicleType, String offenceType, Date date,
			String status, String reportedBy, String place, OwnerDetail owner) {
		super();
		this.offenceDetailId = offenceDetailId;
		this.vehicleNumber = vehicleNumber;
		this.vehicleType = vehicleType;
		this.offenceType = offenceType;
		this.date = date;
		this.status = status;
		this.reportedBy = reportedBy;
		this.place = place;
		this.owner = owner;
	}

	public Integer getOffenceDetailId() {
		return offenceDetailId;
	}

	public void setOffenceDetailId(Integer offenceDetailId) {
		this.offenceDetailId = offenceDetailId;
	}

	public String getVehicleNumber() {
		return vehicleNumber;
	}

	public void setVehicleNumber(String vehicleNumber) {
		this.vehicleNumber = vehicleNumber;
	}

	public String getVehicleType() {
		return vehicleType;
	}

	public void setVehicleType(String vehicleType) {
		this.vehicleType = vehicleType;
	}

	public String getOffenceType() {
		return offenceType;
	}

	public void setOffenceType(String offenceType) {
		this.offenceType = offenceType;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getReportedBy() {
		return reportedBy;
	}

	public void setReportedBy(String reportedBy) {
		this.reportedBy = reportedBy;
	}

	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

	public OwnerDetail getOwner() {
		return owner;
	}

	public void setOwner(OwnerDetail owner) {
		this.owner = owner;
	}

	@Override
	public String toString() {
		return "Details [offenceDetailId=" + offenceDetailId + ", vehicleNo=" + vehicleNumber + ", vehicleType="
				+ vehicleType + ", offenceType=" + offenceType + ", date=" + date + ", status=" + status
				+ ", reportedBy=" + reportedBy + ", place=" + place + ", ownerDetailsRef=" + owner + "]";
	}
	
}
