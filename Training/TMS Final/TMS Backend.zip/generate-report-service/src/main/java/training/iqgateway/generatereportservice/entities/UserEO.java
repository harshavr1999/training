package training.iqgateway.generatereportservice.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="TM_USERMASTER")
public class UserEO{
	
	@Id
	@Column(name="USERNAME")
	private String userName;
	
	@Column(name="PASSWORD")
	private String password;
	
	@ManyToOne
	@JoinColumn(name="ROLENAME")
	private RoleEO roleEO;
	
	public UserEO() {
		// TODO Auto-generated constructor stub
	}

	public UserEO(String userName, String password, RoleEO roleEO) {
		super();
		this.userName = userName;
		this.password = password;
		this.roleEO = roleEO;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public RoleEO getRoleEO() {
		return roleEO;
	}

	public void setRoleEO(RoleEO roleEO) {
		this.roleEO = roleEO;
	}

	@Override
	public String toString() {
		return "UserEO [userName=" + userName + ", password=" + password + ", roleEO=" + roleEO + "]";
	}
	
}
