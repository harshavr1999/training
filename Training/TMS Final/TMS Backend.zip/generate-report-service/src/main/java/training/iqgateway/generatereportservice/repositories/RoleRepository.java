package training.iqgateway.generatereportservice.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import training.iqgateway.generatereportservice.entities.RoleEO;

@Repository
public interface RoleRepository extends CrudRepository<RoleEO, String> {

}
