package training.iqgateway.generatereportservice.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import training.iqgateway.generatereportservice.entities.VehicleDetailsEO;

@Repository
public interface VehicleDetailsRepository extends CrudRepository<VehicleDetailsEO, Integer> {

}
