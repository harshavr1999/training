package training.iqgateway.generatereportservice.dto;



//@Getter
//@Setter
//@NoArgsConstructor
//@AllArgsConstructor
//@ToString
public class OwnerDetail {
	
	private Integer id;
	private String name;
	private String contactNumber;
	private String address;

	public OwnerDetail() {
		// TODO Auto-generated constructor stub
	}

	public OwnerDetail(Integer id, String name, String contactNumber, String address) {
		super();
		this.id = id;
		this.name = name;
		this.contactNumber = contactNumber;
		this.address = address;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "OwnerDetail [id=" + id + ", name=" + name + ", contactNumber=" + contactNumber + ", address="
				+ address + "]";
	}
	
}
