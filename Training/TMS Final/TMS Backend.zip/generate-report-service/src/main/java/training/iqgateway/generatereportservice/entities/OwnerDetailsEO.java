package training.iqgateway.generatereportservice.entities;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name="TM_OWNERDETAILS")
public class OwnerDetailsEO {

	@Id
	@Column(name="OWNER_ID")
	private Integer ownerId;
	
	@Column(name="FNAME")
	private String firstName;
	
	@Column(name="LNAME")
	private String lastName;
	
	@Column(name="DATEOFBIRTH")
	private Date dob;
	
	@Column(name="LANDLINE_NO")
	private String landlineNo;
	
	@Column(name="MOBILE_NO")
	private String mobileNo;
	
	@Column(name="GENDER")
	private Character gender;
	
	@Column(name="TEMP_ADDR")
	private String tempAddress;
	
	@Column(name="PERM_ADDR")
	private String permAddress;
	
	@Column(name="PINCODE")
	private Integer pincode;
	
	@Column(name="OCCUPATION")
	private String occupation;
	
	@Column(name="PANCARD_NO")
	private String pancardNo;
	
	@Column(name="AADHAR_NO")
	private String addProofName;
	
	public OwnerDetailsEO() {
		// TODO Auto-generated constructor stub
	}

	public OwnerDetailsEO(Integer ownerId, String firstName, String lastName, Date dob, String landlineNo,
			String mobileNo, Character gender, String tempAddress, String permAddress, Integer pincode,
			String occupation, String pancardNo, String addProofName) {
		super();
		this.ownerId = ownerId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dob = dob;
		this.landlineNo = landlineNo;
		this.mobileNo = mobileNo;
		this.gender = gender;
		this.tempAddress = tempAddress;
		this.permAddress = permAddress;
		this.pincode = pincode;
		this.occupation = occupation;
		this.pancardNo = pancardNo;
		this.addProofName = addProofName;
	}

	public Integer getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(Integer ownerId) {
		this.ownerId = ownerId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getLandlineNo() {
		return landlineNo;
	}

	public void setLandlineNo(String landlineNo) {
		this.landlineNo = landlineNo;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public Character getGender() {
		return gender;
	}

	public void setGender(Character gender) {
		this.gender = gender;
	}

	public String getTempAddress() {
		return tempAddress;
	}

	public void setTempAddress(String tempAddress) {
		this.tempAddress = tempAddress;
	}

	public String getPermAddress() {
		return permAddress;
	}

	public void setPermAddress(String permAddress) {
		this.permAddress = permAddress;
	}

	public Integer getPincode() {
		return pincode;
	}

	public void setPincode(Integer pincode) {
		this.pincode = pincode;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getPancardNo() {
		return pancardNo;
	}

	public void setPancardNo(String pancardNo) {
		this.pancardNo = pancardNo;
	}

	public String getAddProofName() {
		return addProofName;
	}

	public void setAddProofName(String addProofName) {
		this.addProofName = addProofName;
	}

	@Override
	public String toString() {
		return "OwnerDetailsEO [ownerId=" + ownerId + ", firstName=" + firstName + ", lastName=" + lastName + ", dob="
				+ dob + ", landlineNo=" + landlineNo + ", mobileNo=" + mobileNo + ", gender=" + gender
				+ ", tempAddress=" + tempAddress + ", permAddress=" + permAddress + ", pincode=" + pincode
				+ ", occupation=" + occupation + ", pancardNo=" + pancardNo + ", addProofName=" + addProofName + "]";
	}
	
}

