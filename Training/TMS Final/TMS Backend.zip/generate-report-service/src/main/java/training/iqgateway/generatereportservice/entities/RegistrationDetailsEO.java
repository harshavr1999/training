package training.iqgateway.generatereportservice.entities;

import java.sql.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;



@Entity
@Table(name="TM_REGDETAILS")
public class RegistrationDetailsEO {
	
	@Id
	@Column(name="VEH_NO")
	private String vehicleNo;
	
	@Column(name="APP_NO")
	private Integer applicationNo;
	
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "VEH_ID")
    private VehicleDetailsEO vehicleDetailsEO;
	
	@ManyToOne
	@JoinColumn(name="OWNER_ID")
	private OwnerDetailsEO ownerDetailsEO;
	
	@Column(name="DATE_OF_PURCHASE")
	private Date purchaseDate;
	
	@Column(name="DISTRUBUTER_NAME")
	private String distributorName;
	
	public RegistrationDetailsEO() {
		// TODO Auto-generated constructor stub
	}

	public RegistrationDetailsEO(String vehicleNo, Integer applicationNo, VehicleDetailsEO vehicleDetailsEO,
			OwnerDetailsEO ownerDetailsEO, Date purchaseDate, String distributorName) {
		super();
		this.vehicleNo = vehicleNo;
		this.applicationNo = applicationNo;
		this.vehicleDetailsEO = vehicleDetailsEO;
		this.ownerDetailsEO = ownerDetailsEO;
		this.purchaseDate = purchaseDate;
		this.distributorName = distributorName;
	}

	public String getVehicleNo() {
		return vehicleNo;
	}

	public void setVehicleNo(String vehicleNo) {
		this.vehicleNo = vehicleNo;
	}

	public Integer getApplicationNo() {
		return applicationNo;
	}

	public void setApplicationNo(Integer applicationNo) {
		this.applicationNo = applicationNo;
	}

	public VehicleDetailsEO getVehicleDetailsEO() {
		return vehicleDetailsEO;
	}

	public void setVehicleDetailsEO(VehicleDetailsEO vehicleDetailsEO) {
		this.vehicleDetailsEO = vehicleDetailsEO;
	}

	public OwnerDetailsEO getOwnerDetailsEO() {
		return ownerDetailsEO;
	}

	public void setOwnerDetailsEO(OwnerDetailsEO ownerDetailsEO) {
		this.ownerDetailsEO = ownerDetailsEO;
	}

	public Date getPurchaseDate() {
		return purchaseDate;
	}

	public void setPurchaseDate(Date purchaseDate) {
		this.purchaseDate = purchaseDate;
	}

	public String getDistributorName() {
		return distributorName;
	}

	public void setDistributorName(String distributorName) {
		this.distributorName = distributorName;
	}

	@Override
	public String toString() {
		return "RegistrationDetailsEO [vehicleNo=" + vehicleNo + ", applicationNo=" + applicationNo
				+ ", vehicleDetailsEO=" + vehicleDetailsEO + ", ownerDetailsEO=" + ownerDetailsEO + ", purchaseDate="
				+ purchaseDate + ", distributorName=" + distributorName + "]";
	}
	
}
