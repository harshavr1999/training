package training.iqgateway.generatereportservice.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import training.iqgateway.generatereportservice.entities.RegistrationDetailsEO;

@Repository
public interface RegistrationDetailsRepository extends CrudRepository<RegistrationDetailsEO, String> {

}
