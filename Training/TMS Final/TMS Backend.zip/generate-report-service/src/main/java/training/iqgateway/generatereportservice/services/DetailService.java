package training.iqgateway.generatereportservice.services;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import training.iqgateway.generatereportservice.dto.Details;
import training.iqgateway.generatereportservice.dto.OwnerDetail;
import training.iqgateway.generatereportservice.entities.OffenceDetailEO;
import training.iqgateway.generatereportservice.repositories.OffenceDetailRepository;
//import training.iqgateway.generatereportservice.repositories.OffenceRepository;
//import training.iqgateway.generatereportservice.repositories.OwnerDetailsRepository;
//import training.iqgateway.generatereportservice.repositories.RegistrationDetailsRepository;
//import training.iqgateway.generatereportservice.repositories.VehicleDetailsRepository;

@Service
public class DetailService {
	
	@Autowired
	private OffenceDetailRepository offenceDetailRepositoryRef;
//	@Autowired
//	private OffenceRepository offenceRepositoryRef;
//	@Autowired
//	private OwnerDetailsRepository ownerDetailsRepositoryRef;
//	@Autowired
//	private RegistrationDetailsRepository registrationDetailsRepositoryRef;
//	@Autowired
//	private VehicleDetailsRepository vehicleDetailsRepositoryRef;
	
	public List<Details> getAllDetails() {
		List<OffenceDetailEO> offenceDetailsList = new ArrayList<>(); 
		offenceDetailRepositoryRef.findAll().forEach(offenceDetailsList::add);
		List<Details> result = new ArrayList<Details>();
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		
		for(OffenceDetailEO offenceDetails : offenceDetailsList) {
			Details detail = new Details();
			detail.setOffenceDetailId(offenceDetails.getOffenceDetailId());
			detail.setVehicleNumber(offenceDetails.getRegistrationDetailsEO().getVehicleNo());
			detail.setVehicleType(offenceDetails.getRegistrationDetailsEO().getVehicleDetailsEO().getVehicleType());
			detail.setOffenceType(offenceDetails.getOffenceEO().getOffenceType());
			detail.setDate(offenceDetails.getTime());
			detail.setStatus(offenceDetails.getOffenceStatus());
			detail.setReportedBy(offenceDetails.getUserEO().getUserName());
			detail.setPlace(offenceDetails.getPlace());
			detail.setOwner(
						new OwnerDetail(
								offenceDetails.getRegistrationDetailsEO().getOwnerDetailsEO().getOwnerId(),
								offenceDetails.getRegistrationDetailsEO().getOwnerDetailsEO().getFirstName() + " " +
								offenceDetails.getRegistrationDetailsEO().getOwnerDetailsEO().getLastName(),
								offenceDetails.getRegistrationDetailsEO().getOwnerDetailsEO().getMobileNo(),
								offenceDetails.getRegistrationDetailsEO().getOwnerDetailsEO().getPermAddress()
								)
					);
			
			result.add(detail);
		}	
		
		return result;
	}

}
