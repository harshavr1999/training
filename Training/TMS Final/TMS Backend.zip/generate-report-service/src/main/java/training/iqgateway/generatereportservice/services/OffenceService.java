package training.iqgateway.generatereportservice.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import training.iqgateway.generatereportservice.dto.Offence;
import training.iqgateway.generatereportservice.entities.OffenceEO;
import training.iqgateway.generatereportservice.repositories.OffenceRepository;

@Service
public class OffenceService {
	
	@Autowired
	private OffenceRepository offenceRepositoryRef;

	public List<Offence> getAllOffences() {
		List<OffenceEO> offenceList = new ArrayList<>();
		offenceRepositoryRef.findAll().forEach(offenceList::add);
		List<Offence> result = new ArrayList<>();
		Integer id = 0;
		
		for(OffenceEO offences : offenceList) {
			Offence offence = new Offence();
			offence.setId(id++);
			offence.setName(offences.getOffenceType());
			result.add(offence);
		}
		return result;
	}

}
