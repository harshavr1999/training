package training.iqgateway.generatereportservice.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import training.iqgateway.generatereportservice.entities.OffenceEO;

@Repository
public interface OffenceRepository extends CrudRepository<OffenceEO, Integer> {

}
