package training.iqgateway.generatereportservice.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import training.iqgateway.generatereportservice.entities.OffenceDetailEO;

@Repository
public interface OffenceDetailRepository extends CrudRepository<OffenceDetailEO, Integer> {

}
