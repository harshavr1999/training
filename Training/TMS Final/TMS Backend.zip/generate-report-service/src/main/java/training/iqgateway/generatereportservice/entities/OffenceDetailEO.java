package training.iqgateway.generatereportservice.entities;

import java.io.FileInputStream;
import java.sql.Date;
import java.util.Arrays;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;



@Entity
@Table(name="TM_OFFENCE_DETAILS")
public class OffenceDetailEO {
	
	@Id
	@Column(name="OFFENCE_DETAIL_ID")
	private Integer offenceDetailId;
	
	@ManyToOne
	@JoinColumn(name="VEH_NO")
	private RegistrationDetailsEO registrationDetailsEO;
	
	@ManyToOne
	@JoinColumn(name="OFFENCE_ID")
	private OffenceEO offenceEO;
	
	@Column(name="TIME")
	private Date time;
	
	@Column(name="OFFENCE_STATUS")
	private String offenceStatus;
	
	@ManyToOne
	@JoinColumn(name="REPORTED_BY")
	private UserEO userEO;
	
	@Column(name="PLACE")
	private String place;
	
	@Lob
    @Column(name = "IMAGE", columnDefinition = "BLOB")
    private byte[] image;
	
	public OffenceDetailEO() {
		// TODO Auto-generated constructor stub
	}

	public OffenceDetailEO(Integer offenceDetailId, RegistrationDetailsEO registrationDetailsEO, OffenceEO offenceEO,
			Date time, String offenceStatus, UserEO userEO, String place, byte[] image) {
		super();
		this.offenceDetailId = offenceDetailId;
		this.registrationDetailsEO = registrationDetailsEO;
		this.offenceEO = offenceEO;
		this.time = time;
		this.offenceStatus = offenceStatus;
		this.userEO = userEO;
		this.place = place;
		this.image = image;
	}

	public Integer getOffenceDetailId() {
		return offenceDetailId;
	}

	public void setOffenceDetailId(Integer offenceDetailId) {
		this.offenceDetailId = offenceDetailId;
	}

	public RegistrationDetailsEO getRegistrationDetailsEO() {
		return registrationDetailsEO;
	}

	public void setRegistrationDetailsEO(RegistrationDetailsEO registrationDetailsEO) {
		this.registrationDetailsEO = registrationDetailsEO;
	}

	public OffenceEO getOffenceEO() {
		return offenceEO;
	}

	public void setOffenceEO(OffenceEO offenceEO) {
		this.offenceEO = offenceEO;
	}

	public Date getTime() {
		return time;
	}

	public void setTime(Date time) {
		this.time = time;
	}

	public String getOffenceStatus() {
		return offenceStatus;
	}

	public void setOffenceStatus(String offenceStatus) {
		this.offenceStatus = offenceStatus;
	}

	public UserEO getUserEO() {
		return userEO;
	}

	public void setUserEO(UserEO userEO) {
		this.userEO = userEO;
	}

	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

	public byte[] getImage() {
		return image;
	}

	public void setImage(byte[] image) {
		this.image = image;
	}

	@Override
	public String toString() {
		return "OffenceDetailEO [offenceDetailId=" + offenceDetailId + ", registrationDetailsEO="
				+ registrationDetailsEO + ", offenceEO=" + offenceEO + ", time=" + time + ", offenceStatus="
				+ offenceStatus + ", userEO=" + userEO + ", place=" + place + ", image=" + Arrays.toString(image) + "]";
	}
	
}
