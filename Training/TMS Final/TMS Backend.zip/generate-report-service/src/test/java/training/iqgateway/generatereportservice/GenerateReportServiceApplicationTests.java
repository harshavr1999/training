package training.iqgateway.generatereportservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GenerateReportServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
