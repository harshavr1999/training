package tms.rto.Offence;
import java.util.List;

public interface RTOService {
	
	public List<OffenceEO> getAllOffences();
	
	public void addOffence(OffenceEO offenceEO);
	
	public OffenceEO getOffenceByType(String gType);
	
	public void deleteOffence(int offenceId);
	
	public void updateOffence(OffenceEO offence);
	
	public OffenceEO findOffenceById(Integer id);
	
	public List<Integer> allOffenceTypeIds();

}
