package tms.rto.Offence;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
public class RTOController {
	
	@Autowired
	private RTOService rtoServiceRef;
	
	@RequestMapping(value="/allOffenceTypes")
	public List<OffenceEO> fetchAllOffences(){
		return rtoServiceRef.getAllOffences();
	}
	
	@RequestMapping(value="/add-offence",method=RequestMethod.POST)
	public void addOffence(@RequestBody OffenceEO offenceEO){
		rtoServiceRef.addOffence(offenceEO);;
	}
	
	@DeleteMapping(value="/delete-offence/{id}")
	public void deleteOffence(@PathVariable("id") Integer id){
		rtoServiceRef.deleteOffence(id);
	}
	
	@PutMapping(value="/update-offence")
	public void updateOffence(@RequestBody OffenceEO offenceEO){
		rtoServiceRef.updateOffence(offenceEO);
	}
	
	@GetMapping(value="/findOffenceById/{id}")
	public OffenceEO findOffenceById(@PathVariable("id") Integer id){
		return rtoServiceRef.findOffenceById(id);
	}
	
	@GetMapping("/allOffenceTypeIds")
    public List<Integer> fetchAllOffenceTypeIds(){
        return rtoServiceRef.allOffenceTypeIds();
    }
	
}
