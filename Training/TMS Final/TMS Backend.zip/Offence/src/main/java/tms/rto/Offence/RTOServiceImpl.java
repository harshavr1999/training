package tms.rto.Offence;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RTOServiceImpl implements RTOService {
	
	@Autowired
	private OffenceRepository offenceRepoRef;

	@Override
	public List<OffenceEO> getAllOffences() {
		// TODO Auto-generated method stub
		List<OffenceEO> offenceList= new ArrayList<>();
		offenceRepoRef.findAll().forEach(offenceList::add);
		return offenceList;
	}

	@Override
	public void addOffence(OffenceEO offenceEO) {
		// TODO Auto-generated method stub
		offenceRepoRef.save(offenceEO);

	}

	@Override
	public OffenceEO getOffenceByType(String gType) {
		OffenceEO offRef=offenceRepoRef.findByOffenceType(gType);
		return offRef;
	}

	@Override
	public void deleteOffence(int offenceId) {
		// TODO Auto-generated method stub
		offenceRepoRef.deleteById(offenceId);
		
	}

	@Override
	public void updateOffence(OffenceEO offence) {
		// TODO Auto-generated method stub
		if(offenceRepoRef.existsById(offence.getOffenceId()) ){
			offenceRepoRef.save(offence);
		}else {
			System.out.println("Id does not Exist...");
		}
		
		
	}

	@Override
	public OffenceEO findOffenceById(Integer id) {
		// TODO Auto-generated method stub
		if(offenceRepoRef.existsById(id)){
			return offenceRepoRef.findByOffenceId(id);
		}else{
			return null;
		}
	}
	
	@Override
    public List<Integer> allOffenceTypeIds() {
        // TODO Auto-generated method stub
        List<Integer> offenceTypeList = new ArrayList<Integer>();
        offenceRepoRef.allOffenceTypeIds().forEach(offenceTypeList::add);
        return offenceTypeList;
    }

}
