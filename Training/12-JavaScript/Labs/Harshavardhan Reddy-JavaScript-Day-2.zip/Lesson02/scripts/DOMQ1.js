function js_style() {
    var newText = document.getElementById("text");
    newText.style.fontFamily = "Times New Roman";
    newText.style.fontSize = "20px";
    newText.style.color = "darkcyan";
}