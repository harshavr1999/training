function removecolor() {
    var options = document.getElementById("colorSelect");
    options.remove(options.selectedIndex);
}
