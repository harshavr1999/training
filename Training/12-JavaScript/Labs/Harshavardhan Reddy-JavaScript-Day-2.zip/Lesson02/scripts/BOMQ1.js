function printContent(){
    window.print();
}