function Compare(x,y){
    if(x>=y){
        return x;
    }else{
        return y;
    }
}

var largerNum=Compare(6,7);
console.log("Larger number is : "+largerNum);