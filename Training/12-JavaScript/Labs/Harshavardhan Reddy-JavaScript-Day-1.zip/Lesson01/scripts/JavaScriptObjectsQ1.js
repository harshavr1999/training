var student={
    name:"David Rayy",
    sclass: "VI",
    rollno:12
};

console.log("name : "+student["name"]+", sclass : "+student["sclass"]+", rollno : "+student["rollno"]);