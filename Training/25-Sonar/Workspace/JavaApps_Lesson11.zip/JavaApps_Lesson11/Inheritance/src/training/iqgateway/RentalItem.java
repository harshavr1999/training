package training.iqgateway;

public class RentalItem extends InventoryItem {
    
}
