package training.iqgateway;

public class AppEntry {
    
    public static void main(String[] args) {
        
        //InventoryItem iobj = new InventoryItem();
        //iobj.
        
        Movie mov1 = new Movie();
        //mov1.
        
        // Storing Sub Class Object in Base Class Reference
        //InventoryItem invObj = new Movie();
        
        // 1.  Compiler Treats it Via Reference, So We will ONLY be Able To 
        //     Access Base Class Properties and Base Class methods
        
        // 2.  If Methods are Overriden in the Derived, Then Overriden Method 
        //     Derived Class is Called.
        //invObj.sayHello();
    }
}
