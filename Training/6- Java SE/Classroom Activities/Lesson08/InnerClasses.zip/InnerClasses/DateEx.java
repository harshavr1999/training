import java.util.Date;
class DateEx 
{
	public static void main(String[] args) 
	{
		Date dobj = new Date();
		System.out.println(dobj);
	}
}
