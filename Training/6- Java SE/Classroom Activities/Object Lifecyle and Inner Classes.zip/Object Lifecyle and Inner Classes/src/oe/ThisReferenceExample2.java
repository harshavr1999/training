package oe;

public class ThisReferenceExample2 {

	public static void main(String[] args) {
		DummyClass2 d1 = new DummyClass2();
		d1.mymethod1();
	}
}