import java.util.*;
public class DateDemo
{
	public static void main(String[] args) 
	{
		Date dobj = new Date();

		System.out.println("The Current Date and Time is " + dobj);
	}
}
