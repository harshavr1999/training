package oe;

public class UserNameTest {
	
	public static void main(String[] args) {
	
		String name = System.getProperty("user.name");
		System.out.println("user.name property = " + name);
	}
}