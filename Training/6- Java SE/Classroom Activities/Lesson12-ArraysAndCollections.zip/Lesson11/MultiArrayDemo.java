class MultiArrayDemo 
{
	public static void main(String[] args) 
	{
		int mulDimarr [][] = new int[3][2];

		mulDimarr [0][0] = 1;
		mulDimarr [0][1] = 1;
		mulDimarr [1][0] = 1;
		mulDimarr [1][1] = 1;
		mulDimarr [2][0] = 1;
		mulDimarr [2][1] = 1;

		
	}
}
