class Customer 
{
	int id;
}
